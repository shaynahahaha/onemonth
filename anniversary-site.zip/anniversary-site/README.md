# 🤎 Anniversary Website

A cozy, Rilakkuma-inspired anniversary site — soft beige, warm browns, blush pink, and all the love.

## ✨ Features
- Password lock screen (`04.20`)
- First-visit intro screen (stored in localStorage)
- Confetti celebration reveal
- Hero, countdown to June 20th, Spotify embed, secret message
- Custom 💗 cursor heart trail
- Floating emoji background decorations
- Fully responsive & Vercel-ready

---

## 🚀 Setup

### 1. Install dependencies
```bash
npm install
```

### 2. Run locally
```bash
npm run dev
```
Visit `http://localhost:5173`

### 3. Build for production
```bash
npm run build
```

---

## 🌐 Deploy on Vercel

1. Push this folder to a GitHub repo
2. Go to [vercel.com](https://vercel.com) → **New Project**
3. Import your repo
4. Framework preset: **Vite** (auto-detected)
5. Click **Deploy** — done! ✅

---

## 🔤 Custom Fonts (Optional)

The site uses **Dancing Script** (Google Fonts) as the title font and **Quicksand** as the body font — these load automatically.

If you'd like to use **Ocean Trace** or **Embolism Spark**:
1. Download the `.ttf` / `.woff2` files and place them in `public/fonts/`
2. In `src/index.css`, add a `@font-face` declaration at the top:

```css
@font-face {
  font-family: 'Ocean Trace';
  src: url('/fonts/OceanTrace.woff2') format('woff2'),
       url('/fonts/OceanTrace.ttf') format('truetype');
  font-weight: normal;
  font-style: normal;
}

@font-face {
  font-family: 'Embolism Spark';
  src: url('/fonts/EmbolismSpark.woff2') format('woff2'),
       url('/fonts/EmbolismSpark.ttf') format('truetype');
  font-weight: normal;
  font-style: normal;
}
```

3. Then update the CSS variables in `src/index.css`:
```css
--font-title: 'Ocean Trace', 'Dancing Script', Georgia, serif;
--font-body:  'Embolism Spark', 'Quicksand', sans-serif;
```

---

## 🔧 Customization

| What | Where |
|------|-------|
| Password | `src/components/LockScreen.jsx` → `const PASSWORD` |
| Target date (countdown) | `src/components/useCountdown.js` → `getTarget()` |
| Spotify track | `src/components/MainSite.jsx` → `<iframe src="...">` |
| All text content | Directly in respective component files |
| Colors | `src/index.css` → `:root` CSS variables |

---

Made with 🤎 and a lot of love.
