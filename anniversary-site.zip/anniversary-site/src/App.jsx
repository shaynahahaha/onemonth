import { useState, useEffect } from 'react'
import CursorTrail from './components/CursorTrail'
import LockScreen from './components/LockScreen'
import IntroScreen from './components/IntroScreen'
import CelebrationScreen from './components/CelebrationScreen'
import MainSite from './components/MainSite'

/*
  FLOW:
  1. lock      — password gate (always shown first)
  2. intro     — "i love you so much handsome" (only on FIRST visit, stored in localStorage)
  3. celebrate — confetti reveal screen
  4. main      — full website
*/

const LS_INTRO_SEEN = 'anniversary_intro_seen'

export default function App() {
  const [screen, setScreen] = useState('lock')

  const handleUnlock = () => {
    const introSeen = localStorage.getItem(LS_INTRO_SEEN)
    if (introSeen) {
      // Returning visitor: skip intro, go straight to celebration
      setScreen('celebrate')
    } else {
      // First visit: show intro
      setScreen('intro')
    }
  }

  const handleIntroEnter = () => {
    localStorage.setItem(LS_INTRO_SEEN, 'true')
    setScreen('celebrate')
  }

  const handleCelebrationDone = () => {
    setScreen('main')
  }

  return (
    <>
      <CursorTrail />

      {screen === 'lock'      && <LockScreen onUnlock={handleUnlock} />}
      {screen === 'intro'     && <IntroScreen onEnter={handleIntroEnter} />}
      {screen === 'celebrate' && <CelebrationScreen onDone={handleCelebrationDone} />}
      {screen === 'main'      && <MainSite />}
    </>
  )
}
