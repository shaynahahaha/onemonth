import BgFloaters from './BgFloaters'
import useCountdown from './useCountdown'

function HeroSection() {
  return (
    <section className="hero-section" id="hero">
      <BgFloaters />

      {/* Corner doodles */}
      <span className="doodle" style={{ top: '8%', left: '4%', animationDelay: '0s', fontSize: '3rem' }}>🧸</span>
      <span className="doodle" style={{ top: '12%', right: '5%', animationDelay: '2s', fontSize: '2.5rem' }}>🍯</span>
      <span className="doodle" style={{ bottom: '10%', left: '6%', animationDelay: '1s', fontSize: '2rem' }}>🤎</span>
      <span className="doodle" style={{ bottom: '8%', right: '4%', animationDelay: '3s', fontSize: '2.5rem' }}>🤍</span>

      <div className="hero-card">
        <span className="hero-top-emoji">🤎</span>
        <h1 className="hero-title">happy 1 month 🤎</h1>
        <div className="hero-divider" />
        <p className="hero-subtitle">
          i love you, your voice, how safe i feel with you,<br />
          and how comfortable we are.
        </p>
      </div>
    </section>
  )
}

function CountdownSection() {
  const { days, hours, minutes, seconds } = useCountdown()

  const items = [
    { value: days,    label: 'days' },
    { value: hours,   label: 'hours' },
    { value: minutes, label: 'mins' },
    { value: seconds, label: 'secs' },
  ]

  return (
    <section className="countdown-section" id="countdown">
      <h2 className="section-title">counting down 🍯</h2>
      <p className="section-subtitle">until june 20th 🤎</p>

      <div className="countdown-grid">
        {items.map(({ value, label }) => (
          <div className="countdown-card" key={label}>
            <div className="countdown-number">
              {String(value).padStart(2, '0')}
            </div>
            <div className="countdown-label">{label}</div>
          </div>
        ))}
      </div>
    </section>
  )
}

function SongSection() {
  return (
    <section className="song-section" id="song">
      <div className="song-container">
        <h2 className="section-title" style={{ marginBottom: '8px' }}>our song 🎵</h2>
        <p className="section-subtitle">"Down Chick" — NBA YoungBoy</p>

        <div className="song-card">
          <div className="spotify-embed">
            <iframe
              title="Our Song"
              src="https://open.spotify.com/embed/track/6GKBsGqXmqCG8GVpLwAHGJ?utm_source=generator&theme=0"
              width="100%"
              height="152"
              frameBorder="0"
              allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture"
              loading="lazy"
            />
          </div>
        </div>
      </div>
    </section>
  )
}

function SecretSection() {
  return (
    <section className="secret-section" id="secret">
      <div className="secret-container">
        <h2 className="section-title" style={{ marginBottom: '32px' }}>a little something 🤎</h2>

        <details className="secret-details">
          <summary className="secret-summary">
            <span>a secret 🤎</span>
            <span className="secret-arrow">▾</span>
          </summary>
          <p className="secret-message">
            sometimes i cry because i never knew i could be loved this much
          </p>
        </details>
      </div>
    </section>
  )
}

function SiteFooter() {
  return (
    <footer className="site-footer">
      <p className="footer-text">made with so much love for you 🤎</p>
      <p className="footer-sub">forever & always yours</p>
    </footer>
  )
}

export default function MainSite() {
  return (
    <div className="main-site">
      <HeroSection />
      <CountdownSection />
      <SongSection />
      <SecretSection />
      <SiteFooter />
    </div>
  )
}
