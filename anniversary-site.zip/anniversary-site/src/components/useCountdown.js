import { useState, useEffect } from 'react'

// Target: June 20th of the current or next year
function getTarget() {
  const now = new Date()
  let target = new Date(now.getFullYear(), 5, 20, 0, 0, 0) // June is month 5
  if (target <= now) {
    target = new Date(now.getFullYear() + 1, 5, 20, 0, 0, 0)
  }
  return target
}

export default function useCountdown() {
  const [timeLeft, setTimeLeft] = useState(() => {
    const diff = getTarget() - new Date()
    return calcParts(diff)
  })

  useEffect(() => {
    const tick = () => {
      const diff = getTarget() - new Date()
      setTimeLeft(calcParts(diff))
    }
    const id = setInterval(tick, 1000)
    return () => clearInterval(id)
  }, [])

  return timeLeft
}

function calcParts(ms) {
  if (ms <= 0) return { days: 0, hours: 0, minutes: 0, seconds: 0 }
  const totalSec = Math.floor(ms / 1000)
  const days    = Math.floor(totalSec / 86400)
  const hours   = Math.floor((totalSec % 86400) / 3600)
  const minutes = Math.floor((totalSec % 3600) / 60)
  const seconds = totalSec % 60
  return { days, hours, minutes, seconds }
}
