const FLOATERS = [
  { emoji: '🧸', x: 5,  y: 10, delay: 0,   dur: 6 },
  { emoji: '🤎', x: 88, y: 20, delay: 1.5, dur: 7 },
  { emoji: '🍯', x: 15, y: 70, delay: 0.8, dur: 8 },
  { emoji: '🤍', x: 75, y: 75, delay: 2.2, dur: 6.5 },
  { emoji: '🧸', x: 50, y: 5,  delay: 1,   dur: 7.5 },
  { emoji: '🍯', x: 92, y: 55, delay: 3,   dur: 6 },
  { emoji: '🤎', x: 3,  y: 45, delay: 2,   dur: 9 },
  { emoji: '🤍', x: 60, y: 90, delay: 0.5, dur: 7 },
  { emoji: '🧸', x: 30, y: 85, delay: 3.5, dur: 8 },
]

export default function BgFloaters() {
  return (
    <div className="bg-floaters" aria-hidden="true">
      {FLOATERS.map((f, i) => (
        <span
          key={i}
          className="bg-floater"
          style={{
            left: f.x + '%',
            top: f.y + '%',
            animationDelay: f.delay + 's',
            animationDuration: f.dur + 's',
          }}
        >
          {f.emoji}
        </span>
      ))}
    </div>
  )
}
