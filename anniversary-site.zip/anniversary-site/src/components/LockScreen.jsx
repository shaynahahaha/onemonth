import { useState } from 'react'
import BgFloaters from './BgFloaters'

const WRONG_MESSAGES = [
  'dumbass 💀',
  'try again babe',
  "you're close 🥺",
  'nope… 😭',
  'are you serious rn',
  'baby no 😩',
  'not even close lmao',
  'think harder 🤎',
]

const PASSWORD = '04.20'

export default function LockScreen({ onUnlock }) {
  const [value, setValue] = useState('')
  const [error, setError] = useState('')
  const [shake, setShake] = useState(false)

  const handleUnlock = () => {
    if (value.trim() === PASSWORD) {
      setError('')
      onUnlock()
    } else {
      const msg = WRONG_MESSAGES[Math.floor(Math.random() * WRONG_MESSAGES.length)]
      setError(msg)
      setShake(true)
      setTimeout(() => setShake(false), 400)
      setValue('')
    }
  }

  const handleKeyDown = (e) => {
    if (e.key === 'Enter') handleUnlock()
  }

  return (
    <div className="lock-screen">
      <BgFloaters />

      {/* Decorative doodles */}
      <span className="doodle" style={{ top: '8%', left: '8%', animationDelay: '0s' }}>🧸</span>
      <span className="doodle" style={{ top: '12%', right: '10%', animationDelay: '1.5s' }}>🤎</span>
      <span className="doodle" style={{ bottom: '12%', left: '6%', animationDelay: '2s' }}>🍯</span>
      <span className="doodle" style={{ bottom: '8%', right: '8%', animationDelay: '0.8s' }}>🤍</span>

      <div className="lock-card">
        <span className="lock-emoji">🤎</span>
        <h1 className="lock-title">i love you</h1>
        <p className="lock-subtitle">enter the secret to continue ✨</p>

        <div className="lock-input-wrap">
          <input
            className={`lock-input${shake ? ' error' : ''}`}
            type="password"
            placeholder="••••••"
            value={value}
            onChange={e => { setValue(e.target.value); setError('') }}
            onKeyDown={handleKeyDown}
            autoComplete="off"
            autoFocus
          />
        </div>

        <p className="lock-error">{error || '\u00A0'}</p>

        <button className="lock-btn" onClick={handleUnlock}>
          unlock 🤎
        </button>
      </div>
    </div>
  )
}
