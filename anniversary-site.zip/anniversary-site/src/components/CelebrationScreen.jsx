import { useMemo } from 'react'

const CONFETTI_EMOJIS = ['🤎', '🍯', '🧸', '🤍', '💗', '✨', '🎀', '💛', '🍂', '💖']

function ConfettiPiece({ emoji, style }) {
  return (
    <span className="confetti-piece" style={style} aria-hidden="true">
      {emoji}
    </span>
  )
}

export default function CelebrationScreen({ onDone }) {
  const pieces = useMemo(() => {
    return Array.from({ length: 30 }, (_, i) => {
      const emoji = CONFETTI_EMOJIS[i % CONFETTI_EMOJIS.length]
      const left = Math.random() * 100
      const dur = 3 + Math.random() * 4
      const delay = Math.random() * 4
      const size = 1 + Math.random() * 0.8
      return { emoji, left, dur, delay, size, id: i }
    })
  }, [])

  return (
    <div className="celebration-screen">
      {pieces.map(p => (
        <ConfettiPiece
          key={p.id}
          emoji={p.emoji}
          style={{
            left: p.left + '%',
            animationDuration: p.dur + 's',
            animationDelay: p.delay + 's',
            fontSize: p.size + 'rem',
          }}
        />
      ))}

      <div className="celebration-content">
        <p style={{
          fontSize: '3.5rem',
          marginBottom: '20px',
          animation: 'pulse 1.5s ease-in-out infinite',
          display: 'block',
        }}>🤎</p>

        <h1 className="celebration-title">
          happy 1 month 🤎
        </h1>

        <p className="celebration-sub">
          you are my favorite person in the whole wideeee world
        </p>

        <button className="celebration-btn" onClick={onDone}>
          enter our world 🧸
        </button>
      </div>
    </div>
  )
}
