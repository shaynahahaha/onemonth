import { useEffect } from 'react'

export default function CursorTrail() {
  useEffect(() => {
    let lastX = 0
    let lastY = 0
    let ticking = false
    const hearts = []
    const MAX_HEARTS = 18

    const createHeart = (x, y) => {
      // Remove oldest if limit reached
      if (hearts.length >= MAX_HEARTS) {
        const old = hearts.shift()
        if (old && old.parentNode) old.parentNode.removeChild(old)
      }

      const el = document.createElement('span')
      el.className = 'cursor-heart'
      el.textContent = '💗'
      el.style.left = x + 'px'
      el.style.top = y + 'px'
      el.style.fontSize = (10 + Math.random() * 8) + 'px'
      document.body.appendChild(el)
      hearts.push(el)

      // Remove after animation ends
      el.addEventListener('animationend', () => {
        if (el.parentNode) el.parentNode.removeChild(el)
        const idx = hearts.indexOf(el)
        if (idx > -1) hearts.splice(idx, 1)
      })
    }

    let moveCount = 0
    const handleMouseMove = (e) => {
      lastX = e.clientX
      lastY = e.clientY
      moveCount++

      // Throttle: create heart every 3rd move event
      if (moveCount % 3 !== 0) return
      if (ticking) return
      ticking = true

      requestAnimationFrame(() => {
        createHeart(lastX, lastY)
        ticking = false
      })
    }

    window.addEventListener('mousemove', handleMouseMove, { passive: true })

    return () => {
      window.removeEventListener('mousemove', handleMouseMove)
      hearts.forEach(h => { if (h.parentNode) h.parentNode.removeChild(h) })
    }
  }, [])

  return null
}
