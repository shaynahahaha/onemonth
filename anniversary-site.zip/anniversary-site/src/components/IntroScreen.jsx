import BgFloaters from './BgFloaters'

export default function IntroScreen({ onEnter }) {
  return (
    <div className="intro-screen">
      <BgFloaters />

      <span className="doodle" style={{ top: '10%', left: '5%', animationDelay: '0s', opacity: 0.15 }}>🧸</span>
      <span className="doodle" style={{ bottom: '10%', right: '6%', animationDelay: '1s', opacity: 0.15 }}>🍯</span>

      <div className="intro-card">
        <p style={{
          fontSize: '3rem',
          marginBottom: '24px',
          display: 'block',
          animation: 'gentleBounce 2.5s ease-in-out infinite',
        }}>🤎</p>

        <h1 className="intro-title">
          i love you so much handsome
        </h1>

        <p className="intro-sub">mwa mwa mwa</p>

        <button className="btn-primary" onClick={onEnter}>
          click 2 enter 🧸
        </button>
      </div>
    </div>
  )
}
